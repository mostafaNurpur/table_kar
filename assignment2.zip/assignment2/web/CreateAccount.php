<?php
    include('db.php');
    if(isset($_POST) & !empty($_POST)){
        $firstname   = $_POST['f-name'];
        $lastname    = $_POST['family'];
        $username    = $_POST['username'];
        $password    = $_POST['password'];

        $sql = "INSERT INTO `control` (name, family , username, password) VALUES ('$firstname', '$lastname' , '$username', '$password')";

        $result = mysqli_query($con, $sql);
        if ($result){
            $smsg =("ثبت نام با موفقیت انجام شد");
            header( "refresh:5; url=login.php" );
        }else{
            $fmsg =("ثبت نام با مشکل مواجه شده است");
            header( "refresh:5; url=login.php" );
        }
    }
    ?>
<html>
    <head>
        <title>create account</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    </head>

    <body ng-controller="RegisterCtrl" ng-app="myApp">
    <?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert" style="width: 15% ; margin-left: 42%"> <?php echo $smsg; ?> </div>
    <?php } ?>
    <?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert" style="width: 15% ; margin-left: 42%"> <?php echo $fmsg; ?> </div>
    <?php } ?>
        <form method="POST" action="CreateAccount.php" role="login">
            <div class="float-label">
                <input type="text" name="f-name" id="f-name" required />
                <label for="f-name">Name</label>
            </div>
            <div class="float-label">
                <input type="text" name="family" id="family" required />
                <label for="family">family</label>
            </div>
            <!--Row-->
            <div class='row'>
                <!--//row-->
            </div>
            <div class="float-label">
                <fa class="fa eye fa-eye-slash"></fa>
                <input type="text" name="username" id="username" required />
                <label for="username">username</label>
            </div>
            <div class="float-label">
                <input type="password" name="password" id="password" required>
                <label for="password">password</label>
            </div>
            <button class="btn" type="submit" id="sub" onclick="send()">Submit</button>
            <button class="btn" id="clear" type="reset" value="Reset">Reset</button>
        </form>
    </body>
</html>
<style>
    @import url(https://fonts.googleapis.com/css?family=Lato:100,300,400);

    html {
        line-height: 1;
    }
    table {
        border-collapse: collapse;
        border-spacing: 0;
    }
    * {
        -moz-box-sizing: border-box;
        -webkit-box-sizing: border-box;
        box-sizing: border-box;
    }
    html,
    body {
        margin: 5%;
        background-attachment: fixed;
    }
    body {
        font-family: 'Lato', sans-serif;
        font-weight: 400;
        background-color:#6f6f6f;
        background-size: 100%;
        color: #fff;
    }

    .confirm h1 {
        margin: 0 auto;
        margin-top: 35vh;
        display: inline-block;
        font-size: 48px;
        line-height: 1;
    }
    .confirm h1 .fa {
        display: block;
    }

    form {
        max-width: 500px;
        margin: 0 auto;
        padding: 20px;
    }

    .row div {
        width: 33.33333333333333%;
        display: inline-block;
        margin-right: -5px;
        position: relative;
    }
    .row  div:after {
        content: '';
        border-right: 1px solid rgba(255, 255, 255, 0.7);
        position: absolute;
        top: 3px;
        height: 75%;
        right: -3px;
    }
    .row div:last-child:after {
        display: none;
    }

    h1 {
        font-weight: 300;
        font-size: 26px;
        line-height: 3;
        margin-bottom: 25px;
        text-align: center;
    }


    .btn {
        font-family: 'Lato', sans-serif;
        border: none;
        width: 100%;
        display: block;
        padding: 15px;
        background-color: #fff;
        font-size: 18px;
        color: #4d4d4d;
        cursor: pointer;
        -moz-transition: all 0.3s ease;
        -o-transition: all 0.3s ease;
        -webkit-transition: all 0.3s ease;
        transition: all 0.3s ease;
        -moz-border-radius: 0;
        -webkit-border-radius: 0;
        border-radius: 0;
    }
    .btn:hover, .btn:focus {
        color: #333;
        outline: none;
    }

    #clear {
        background: none;
        color: #fff;
        font-weight: 100;
    }

    .float-label {
        position: relative;
        margin-bottom: 10px;
    }
    .float-label label, .float-label input, .float-label select, .float-label textarea {
        font-family: 'Lato', sans-serif;
        font-size: 24px;
        font-weight: 300;
    }
    .float-label input, .float-label select, .float-label textarea {
        -webkit-appearance: none;
        outline: none;
        border: none;
        width: 100%;
        display: block;
        cursor: pointer;
        -moz-border-radius: 0;
        -webkit-border-radius: 0;
        border-radius: 0;
        font-family: 'Lato', sans-serif;
        font-size: 24px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.7);
        background: transparent;
        color: #fff;
        padding: 15px 20px 10px 10px;
    }
    .float-label label {
        position: absolute;
        left: 10px;
        top: 18px;
        color: #fff;
        pointer-events: none;
        -moz-transition: all 0.2s ease;
        -o-transition: all 0.2s ease;
        -webkit-transition: all 0.2s ease;
        transition: all 0.2s ease;
    }
    .float-label label.active {
        font-size: 14px;
        font-weight: 400;
        top: -1px;
        color: rgba(0, 0, 0, 0.7);
    }
    .float-label textarea {
        height: 100px;
        resize: none;
    }
    .float-label .fa {
        position: absolute;
        right: 5px;
        bottom: 20px;
        font-size: 12px;
    }
    .float-label .fa.eye {
        right: 0;
        bottom: 2px;
        z-index: 10;
        padding: 20px;
        padding-right: 0;
        font-size: 16px;
        cursor: pointer;
        color: rgba(0, 0, 0, 0.5);
    }
    .float-label .fa.eye.show {
        color: rgba(255, 255, 255, 0.9);
    }

    @media (max-width: 320px) {
        .row > div {
            display: block;
            width: auto;
        }
        .row > div:after {
            display: none;
        }
    }

</style>
<script>
    (function($){
        function floatLabel(inputType){
            $(inputType).each(function(){
                var input = $(this).find("input, select, textarea");
                var label = $(this).find("label");
                // on focus add cladd active to label
                input.focus(function(){
                    input.next().addClass("active");
                    console.log("focus");
                });
                //on blur check field and remove class if needed
                input.blur(function(){
                    if(input.val() === '' || input.val() === 'blank'){
                        label.removeClass();
                    }
                });
            });
        }
        // just add a class of "floatLabel to any group you want to have the float label interactivity"
        floatLabel(".float-label");


//////  Just a bunch of fluff for other interactions  ////////////////////////////////////////////////////////

        //for the pw field - toggle visibility
        $(".eye").on("click" , function(){
            var $this = $(this);
            if( !$this.is(".show") ){
                $this.addClass("show")
                    .removeClass("fa-eye-slash")
                    .addClass("fa-eye").next()
                    .attr("type" , "text");
            }else{
                $this.removeClass("show")
                    .addClass("fa-eye-slash")
                    .removeClass("fa-eye")
                    .next().attr("type" , "password");
            }
        });

        //modal close
        $(".close").on("click" , function(){
            $(this).parent().removeClass("show");
            $("#clear").click();
        })

        //just for reset button
        $("#clear").on("click" , function(){
            $(".active").removeClass("active");
        });

    })(jQuery);
</script>