<?php
include("db.php");
session_start();
if($_POST)
{
    $username = $_POST['uname'];
    $password = $_POST['psw'];

    $query="SELECT * FROM  `control` WHERE username='$username' AND password='$password' ";

    $result=mysqli_query($con,$query);

    if(mysqli_num_rows($result)==1)
    {
        $tas = mysqli_fetch_assoc($result);

        $_SESSION['uname']   = $tas['username'];
        $_SESSION['psw']     = $tas['password'];
        $_SESSION['name']    = $tas['name'];
        $_SESSION['family']  =$tas['family'];

        if($tas['user_role'] == 1)
        {
            header('location:ControlSystem.php');
        }
        else
        {
            header('location:login.php');
        }

    }
    else{
        $fmsg = ("این نام کاربری / رمزعبور وجود ندارد");
    }




}

?>

<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, height=device-height, minimum-scale=1.0 maximum-scale=1.1, minimal-ui, user-scalable=no">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <title>login page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body background="Autumn_in_Kanas_by_Wang_Jinyu.jpg">

    <?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert" > <?php echo $smsg; ?> </div>
    <?php } ?>
    <?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div>
    <?php } ?>
    <form method="post">
        <input type="image" src="workers.jpg" id="image">
        <div class="container" id="contain">
            <input type="text" placeholder="Enter Username" name="uname" id="txt" required><br/>
            <input type="password" placeholder="Enter Password" name="psw" id="pass" required><br/>
            <button type="submit" id="sub">Login</button><br/>
            <button type="button" id="sub1" onclick="href()">sign in</button><br/>
        </div>
    </form>

</body>

</html>

<script>
    let sub1 = document.getElementById("sub1");
    function href(){
        window.location.href = "CreateAccount.php";
    }
</script>

<style>
    form{
        width: 100%;
    }
    body {
        font-family: Arial, Helvetica, sans-serif;
    }

    input[type=text], input[type=password] {
        border-bottom: 2px solid red;
        padding: 12px 20px;
        margin: 8px 0;
        display: inline-block;
       /* border: 1px solid #ccc;*/
        box-sizing: border-box;
    }

    button {
        background-color: #4CAF50;
        color: white;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        cursor: pointer;

    }

    button:hover {
        opacity: 0.8;
    }

    #contain{
       margin: 3% 20% 0 37%;
    }

    #txt{
        width: 40%;
        border-radius: 10px;
    }
    #pass{
        width: 40%;
        border-radius: 10px;
    }
    #sub{
        width: 40%;
        border-radius: 10px;
    }
    #sub1{
        width: 40%;
        border-radius: 10px;
        background-color: #7a2518;
    }
    #txt:focus
    {
        outline:none;
    }
    #pass:focus
    {
        outline:none;
    }
    #image{
        border-radius: 50%;
        margin: 15% 20% 0 41%;
    }
    .alert-danger{
        width: 20%;
        text-align: center;
        margin-left: 40% ;
    }
</style>
