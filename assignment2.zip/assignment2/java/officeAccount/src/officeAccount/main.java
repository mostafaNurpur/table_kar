//proje java
//hossein samadi & mostafa nurpur 
//
package officeAccount;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		morakhasi mo = new morakhasi();
		Date d = new Date();
		Scanner sc = new Scanner(System.in);
		Scanner s = new Scanner(System.in);
		ArrayList<employee> emp = new ArrayList<employee>();
		while (true){
			System.out.println("1 add 0 vorod :");
			int b = sc.nextInt();
			if (b == 1){
				System.out.println("id : ");
				String id = s.nextLine();
				System.out.println("pas : ");
				String pas = s.nextLine();
				emp.add(new employee(id, pas));
				
				
			}else if (b == 0){
				System.out.println("id  : ");
				String idch = s.nextLine();
				System.out.println("pas : ");
				String pasch = s.nextLine();
				if(cheek(emp, idch, pasch) == 0){
					System.out.println("vared shodid");
					while(true){
						System.out.println("enter :\n"
								+ "1.morakhsi\n"
								+ "2.reserve\n"
								+ "3.exit");
						Scanner m = new Scanner(System.in);
						String chose = m.nextLine();
						if(chose.equals("morakhsi")){
							
							mo.dMorakhsi();
						}else if(chose.equals("reserve")){
							System.out.println("ghaza reserve shod");
						}else if(chose.equals("exit")){
							break;
						}
						
					}
					Date a = new Date();
					long da = (a.getTime()-d.getTime())/1000;
					System.out.println("t :   "+da);
					break;
				}else if (cheek(emp, idch, pasch) == 1)
					System.out.println("id ya password shoma eshtb ast");
				
			}
			
			
			
			
		}
		
		
		
	}
	
	
	
	public static int cheek(ArrayList<employee> e,String id , String pas){
		for (int n=0; n < e.size() ; n++){
			if (id.equals(e.get(n).getName()) && pas.equals(e.get(n).getPassword())){
				
				return 0;
			}
		}
		return 1;
	}
	


}