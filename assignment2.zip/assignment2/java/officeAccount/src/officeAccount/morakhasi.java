package officeAccount;

public class morakhasi {
int counter = 0;

	public void dMorakhsi(){
		counter++;
		if (counter <= 3){
			System.out.println("*****\ndarkhaste shoma sabt gardid\n");
		}else{
			System.out.println("you cannot use this any more\n");
		}
	}

}
